package com.covid_tracker.network.data


/**
 * Created by Dhanshri on 17-06-2020.
 * dhanshri.pathrikar@gmail.com
 */

class Country(val Countries: List<GlobalData>) {

}